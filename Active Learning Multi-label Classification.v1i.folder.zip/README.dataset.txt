# Active Learning Multi-label Classification > 2025-04-19 5:56pm
https://universe.roboflow.com/sign-detection-zgtks/active-learning-multi-label-classification

Provided by a Roboflow user
License: CC BY 4.0

